package com.arcsoft.arcfacedemo.common;

public class Constants {
    public static final String APP_ID = "9BHjZUdQ1pq37WQUGcRAr3s5cqgpXpi44LnT8aHWTqY4";
    public static final String SDK_KEY = "AYDeLJLGhJWcKYN361exB2xWWj1qLZkALXqxnQWZ1MAh";
}
