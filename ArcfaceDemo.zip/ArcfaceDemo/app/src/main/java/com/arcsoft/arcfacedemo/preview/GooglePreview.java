package com.arcsoft.arcfacedemo.preview;

public class GooglePreview extends YZWPreview {

    @Override
    public void start() {
        super.start();
    }
}
