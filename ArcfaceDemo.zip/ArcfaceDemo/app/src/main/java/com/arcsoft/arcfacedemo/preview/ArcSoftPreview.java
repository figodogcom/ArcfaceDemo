package com.arcsoft.arcfacedemo.preview;

public class ArcSoftPreview extends YZWPreview {

    @Override
    public void start() {
        super.start();
    }
}
