package com.arcsoft.arcfacedemo.preview;

public abstract class YZWPreview {

    public void start() {

    }

    public void stop() {

    }




    public void onResume() {

    }

    public void onStop() {

    }

    public interface Callback {

    }

    protected Callback callback;

    public void setCallback(Callback callback) {
        this.callback = callback;
    }
}
